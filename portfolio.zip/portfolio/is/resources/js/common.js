$(function () {
  ScrollTargetOperation();
  ieParallaxDebug();
  aosOperation();
  swiperOperation();
  gnbActivation();
});

function ScrollTargetOperation() {
  var $menu = $('#majorHeader .gnb ul li'),
    $contents = $('.ispPortfolio article'),
    $doc = $('html,body');
  $menu.on('click', 'a', function (e) {
    var $target = $(this).parent(),
      idx = $target.index(),
      section = $contents.eq(idx),
      offsetTop = section.offset().top;
    $doc.stop().animate({
      scrollTop: offsetTop
    }, 400);
    return false;
  });
  // menu class 추가
  gnbMenuLink = $('#majorHeader .gnb ul li a')
  gnbMenuLink.click(function () {
    $('html, body').animate({
      scrollTop: $($.attr(this, 'href')).offset().top
    }, 400);
    return false;
  });
}
function ieParallaxDebug() {
  if (navigator.userAgent.match(/Trident\/7\./)) {
    $('body').on("mousewheel", function () {
      event.preventDefault();
      var wheelDelta = event.wheelDelta;
      var currentScrollPosition = window.pageYOffset;
      window.scrollTo(0, currentScrollPosition - wheelDelta);
    });
    $('body').keydown(function (e) {
      e.preventDefault(); // prevent the default action (scroll / move caret)
      var currentScrollPosition = window.pageYOffset;
      switch (e.which) {
        case 38: // up
          window.scrollTo(0, currentScrollPosition - 120);
          break;
        case 40: // down
          window.scrollTo(0, currentScrollPosition + 120);
          break;
        default:
          return; // exit this handler for other keys
      }
    });
  }
}
function aosOperation() {
  var myAOS = function () {
    AOS.init({
    duration: 1000,
    delay: 100
  });
  }
  myAOS();
}

function swiperOperation() {
  var coverflowSetting = {
    slideShadows: true,
    rotate: 40,
    stretch: 0,
    depth: 100,
    modifier: 1,
  }
  var myswiper = null;

  function init() {
    if (myswiper != null) myswiper.destroy();
    myswiper = new Swiper('.swiper-container', {
      effect: 'coverflow',
      coverflowEffect: coverflowSetting,
      grabCursor: true,
      centeredSlides: true,
      spaceBetween: 20,
      slidesPerView: '5',
      loop: true,
      // autoplay: {
      //   delay: 0,
      // },
      speed: 3000,
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      pagination: {
        el: '.swiper-pagination',
        type: 'progressbar',
        clickable: true,
      },
      breakpoints: {
        320: {
          slidesPerView: 1
        },
        768: {
          slidesPerView: 2
        },
        1280: {
          slidesPerView: 3
        }
      }
    });
  }
  init();
  var mySwiper = document.querySelector('.swiper-container').swiper;
  $('.snp').click(function () {
    if ($(this).hasClass('stop')) {
      mySwiper.autoplay.stop();
      $(this).removeClass('stop').addClass('play').text('재생');
    } else {
      mySwiper.autoplay.start();
      $(this).removeClass('play').addClass('stop').text('정지');
    }
  });
}
function gnbActivation() {
  var $menu = $('#majorHeader .gnb ul li'),
      $contents = $('.container > article'),
      $doc = $('html,body'),
      $scd = $('.scrollDown');

  //  해당 섹션으로 스크롤 이동
  $menu.on('click', 'a', function (e) {
      var $target = $(this).parent(),
          idx = $target.index(),
          section = $contents.eq(idx),
          offsetTop = section.offset().top;
      $doc.stop().animate({
          scrollTop: offsetTop
      }, 400);
      return false;
  });
  function scdBottom()
  {
    $scd.animate({marginBottom:'0'},500,scdTop)
  }

  function scdTop()
  {
    $scd.animate({marginBottom:'8'},500,scdBottom)
  }
  scdBottom();
  // menu class 추가
  $(window).scroll(function () {
      var scltop = $(window).scrollTop();
      $.each($contents, function (idx) {
          var $target = $contents.eq(idx),
              targetTop = $target.offset().top;
          if (targetTop <= scltop) {
              $menu.removeClass('on');
              $menu.eq(idx).addClass('on');
          }
      })
  
  });
}
